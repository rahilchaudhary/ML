"""Local stand-in for the Fleet RUL API - ONLY to check the test code without the real service.

Response shapes copy the real responses (features, fleet, predict). Not part of the framework.
Run tests against it with:  pytest --env local_stand_in

Fault switches (STANDIN_BUG=...) to see each case catch a real defect:
  optional_affects   removing unit_id changes the prediction          -> TC-01 fails
  silent_default     missing mandatory feature is filled silently      -> TC-02 fails
  boundary           RUL equal to the CRITICAL cut-off gives CRITICAL  -> TC-04 fails
  negative_history   one history record has a negative RUL             -> TC-07 fails
STANDIN_FLEET_SIZE=N adds synthetic vehicles, to see how TC-07 behaves on a large fleet.
"""
from __future__ import annotations

import json
import os
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

BUG = os.environ.get("STANDIN_BUG", "")
CUT = {"radiator": (100.0, 300.0)}
REQUIRED = ["radiator_age_hours", "ambient_c", "engine_load_pct", "payload_pct", "blockage_pct",
            "coolant_c", "temperature_drop_c", "coolant_flow_lpm", "overtemperature_minutes",
            "cooling_dtc_count"]
OPTIONAL = ["unit_id", "vin", "vehicle_model", "site", "timestamp"]
FLEET = [
    {"unit_id": "RAD-141", "vin": "MAT426031M1J10142", "vehicle_model": "TATA Signa SYN 6x4", "site": "North Pit",
     "timestamp": "2025-03-30T13:00:00", "radiator_age_hours": 2225, "ambient_c": 32.6, "engine_load_pct": 92.4,
     "payload_pct": 103.8, "blockage_pct": 79.3, "coolant_c": 99.1, "temperature_drop_c": 7.4,
     "coolant_flow_lpm": 28.0, "overtemperature_minutes": 0, "cooling_dtc_count": 0},
    {"unit_id": "RAD-135", "vin": "MAT353021S3C10136", "vehicle_model": "TATA Prima SYN 6x4", "site": "Highway Site",
     "timestamp": "2025-04-21T10:00:00", "radiator_age_hours": 2750, "ambient_c": 37.5, "engine_load_pct": 68.8,
     "payload_pct": 116.5, "blockage_pct": 79.3, "coolant_c": 97.5, "temperature_drop_c": 7.1,
     "coolant_flow_lpm": 22.7, "overtemperature_minutes": 0, "cooling_dtc_count": 0},
    {"unit_id": "RAD-033", "vin": "MAT492531P1J10034", "vehicle_model": "TATA Signa SYN 6x4", "site": "North Pit",
     "timestamp": "2025-06-05T05:00:00", "radiator_age_hours": 3825, "ambient_c": 27.2, "engine_load_pct": 64.8,
     "payload_pct": 103.2, "blockage_pct": 79.2, "coolant_c": 94.3, "temperature_drop_c": 7.3,
     "coolant_flow_lpm": 28.0, "overtemperature_minutes": 0, "cooling_dtc_count": 0},
]

for _i in range(int(os.environ.get("STANDIN_FLEET_SIZE", 0))):
    FLEET.append(dict(FLEET[0], unit_id=f"RAD-{1000 + _i}", vin=f"MAT426031M1J{20000 + _i}"))


def risk(component: str, rul: float) -> str:
    crit, watch = CUT[component]
    if (rul <= crit) if BUG == "boundary" else (rul < crit):
        return "CRITICAL"
    return "WATCH" if rul < watch else "HEALTHY"


def predict(rec: dict) -> dict:
    """Deterministic: same features -> same numbers. Time-based fields change per call, like the real API."""
    rul = max(0.0, 900 - 0.12 * rec["radiator_age_hours"] - 4 * rec["blockage_pct"]
              - 30 * rec["cooling_dtc_count"] + 2 * rec["coolant_flow_lpm"])
    if BUG == "optional_affects" and rec.get("unit_id"):
        rul += 1.0
    now = datetime.now(timezone.utc)
    out = {k: rec.get(k, d) for k, d in zip(OPTIONAL, ["", "", "Unknown", "Unknown", now.isoformat()])}
    out.update({k: rec[k] for k in REQUIRED})
    lower = round(rul * 0.7, 4)
    out.update({"predicted_rul_hours": round(rul, 4), "rul_lower_hours": lower,
                "rul_upper_hours": round(rul * 1.25, 4), "rul_days": round(rul / 18, 1),
                "risk_level": risk("radiator", lower), "recommended_action": "Continue monitoring",
                "cooling_health_score": 59.4, "health_score": 59.4, "failure_probability_pct": 40.6,
                "primary_reason": "Normal monitored degradation", "generated_at_utc": now.isoformat(),
                "service_due_date": (now + timedelta(hours=rul)).isoformat(),
                "service_window_start": (now + timedelta(hours=rul * 0.8)).isoformat(),
                "service_window_end": (now + timedelta(hours=rul * 1.2)).isoformat(),
                "service_urgency": "SCHEDULED", "component": "radiator"})
    return out


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, status, body):
        data = json.dumps(body).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        p = urlparse(self.path).path.strip("/").split("/")
        if p == ["health"]:
            return self._send(200, {"status": "ok"})
        if p == ["api", "registry"]:
            return self._send(200, {"radiator": {"subsystem": "cooling", "trained": True}})
        if p[:2] == ["api", "predict"] and len(p) == 4 and p[3] == "features" and p[2] in CUT:
            return self._send(200, {"component": p[2], "display_name": "Radiator", "required_features": REQUIRED,
                                    "feature_count": len(REQUIRED), "optional_metadata": OPTIONAL,
                                    "endpoint": f"POST /api/predict/{p[2]}"})
        if len(p) == 3 and p[0] == "api" and p[2] == "fleet" and p[1] in CUT:
            return self._send(200, [predict(r) for r in FLEET])
        if len(p) == 5 and p[0] == "api" and p[2] == "vehicle" and p[4] == "history" and p[1] in CUT:
            rec = next((r for r in FLEET if r["unit_id"] == p[3]), None)
            if rec is None:
                return self._send(404, {"detail": "Vehicle not found"})
            hist = [predict(rec), predict(dict(rec, radiator_age_hours=rec["radiator_age_hours"] - 200))]
            if BUG == "negative_history" and p[3] == "RAD-033":
                hist[1]["rul_lower_hours"] = -12.5
            return self._send(200, hist)
        self._send(404, {"detail": "Not Found"})

    def do_POST(self):
        p = urlparse(self.path).path.strip("/").split("/")
        n = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(n) or b"{}")
        if p[:2] == ["api", "recommendation"] and len(p) == 3 and p[2] in CUT:
            rul = body.get("rul_lower_hours")
            if "rul_lower_hours" not in body:
                return self._send(422, {"detail": [{"type": "missing", "loc": ["body", "rul_lower_hours"],
                                                    "msg": "Field required"}]})
            if not isinstance(rul, (int, float)):
                return self._send(422, {"detail": [{"type": "float_type", "loc": ["body", "rul_lower_hours"],
                                                    "msg": "Input should be a valid number"}]})
            r = risk(p[2], rul)
            return self._send(200, {"component": p[2], "rul_lower_hours": rul, "vin": body.get("vin"),
                                    "risk_level": r, "recommended_action": "...", "service_urgency": "..."})
        if p[:2] == ["api", "predict"] and len(p) == 3 and p[2] in CUT:
            missing = [f for f in REQUIRED if f not in body]
            if missing and BUG == "silent_default":
                body.update({f: 0 for f in missing})
                missing = []
            if missing:
                return self._send(422, {"detail": {"error": "Missing required features",
                                                   "missing_features": missing}})
            return self._send(200, predict(body))
        self._send(404, {"detail": "Not Found"})


if __name__ == "__main__":
    port = int(os.environ.get("STANDIN_PORT", 8765))
    print(f"stand-in Fleet RUL API on http://127.0.0.1:{port} (STANDIN_BUG={BUG or 'none'})")
    ThreadingHTTPServer(("127.0.0.1", port), Handler).serve_forever()
