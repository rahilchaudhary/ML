# Servio ML API tests

Seven test cases from `testdata/servio_ml_test_cases.xlsx`, run against the Fleet RUL API.

## What lives where

| Thing | Where | Changes by component? |
|---|---|---|
| Test cases, API path + method per case | `testdata/servio_ml_test_cases.xlsx`, sheet **Test Cases** | No - `{component}` is filled in at run time |
| Test data that applies to every component (incl. fields compared by TC-01) | same workbook, sheet **Test Data** | No |
| Test data tied to one component (e.g. TC-02's field names) | same workbook, sheet **Test Data - Components** (Component column, filterable) | Yes, rows per component |
| Every valid API path and method | `spec/fleet_rul_openapi_v2.0.0.json` (pinned copy of `GET /openapi.json`) | No |
| Cut-offs, agreed mandatory/optional lists (TC-06) | `config/components/<component>.yaml` | Yes, one file each |
| Where and how to run, what is ready to test | `config/settings.yaml` (see below) | No |
| Full prediction request | `testdata/requests/predict/<component>.json` | Yes, one file each |
| Assumed training/testing sets (TC-05) | `testdata/assumed/<component>/` | Yes |
| Mandatory/optional list used by TC-01, TC-02 | fetched at run time: `GET /api/predict/{component}/features` | - |
| Fleet and history records | fetched at run time | - |

## config/settings.yaml - purpose and when to update

Holds **where and how to run, and what is ready to be tested**. No requirements, no test data.
Read only by `framework/settings.py`.

| Section | Update when |
|---|---|
| `environments` | A new environment, or a URL changes |
| `excel` | The workbook moves or is renamed |
| `swagger` | The API changes: download `/openapi.json` again, save as a new file, point here |
| `record_sources` | The training/testing APIs exist: change `type: file` to `type: api` |
| `just_below_step` | Almost never - QA's definition of "Just below" (0.01) |
| `vehicle_sample_size` | To trade run time against coverage for per-vehicle cases (TC-07); default 25 |
| `hierarchy` | A component is ready for testing, or the sub-system grouping changes |

## Anchors - names that must match across files

All are checked when the run starts; a mismatch stops the run before any call.

| Anchor | Links | If it does not match |
|---|---|---|
| Component name (`radiator`) | settings.yaml hierarchy, Test Cases Applicable/Excluded, Test Data - Components Component column, `config/components/<name>.yaml`, `testdata/requests/predict/<name>.json` | Run stops naming the unknown component or missing file |
| API path + Method | Test Cases API/Method columns, a service in `framework/services/`, pinned Swagger | Run stops: path not covered by any service, or service path not in Swagger |
| TC-ID | Test Cases sheet, `@pytest.mark.case("TC-..")` on the test | Traceability test fails |
| Environment name | `--env`, settings.yaml | Run stops naming the unknown environment |


## The pieces (framework/)

| Piece | Its only job |
|---|---|
| `settings.py` | Loads config: environments, hierarchy, each component's requirements |
| `swagger.py` | Says whether a method + path exists in the pinned Swagger |
| `case_reader.py` | Reads the three sheets; stops on any unknown word (Category, Suite, Method, Action) |
| `component_selector.py` | Applicable minus Excluded, within the run's scope. Exclusion wins; empty = NOT APPLICABLE |
| `services/` | One service object per Swagger tag (prediction, recommendation, fleet, system). The only place an API path is written. Tests call e.g. `services.fleet.history(component, unit_id)` |
| `api_client.py` | HTTP only, used by the services; checks every path against Swagger first |
| `request_builder.py` | Full request + one row's action. Recommendation request is a pydantic model (POJO equivalent) |
| `value_resolver.py` | Words in the Value column -> numbers, e.g. "Just below CRITICAL cut-off" -> 99.99 for radiator |
| `result_checker.py` | Compares response with Expected Status / Expected Result |
| `record_source.py` | Records for Read & Verify, from a file or an API (chosen in config) |
| `flows.py` | The Send & Verify flow, written once |
| `vehicle_sample.py` | Picks a reproducible random sample of vehicles for per-vehicle cases (TC-07) |

Tests (`tests/`) are one function per test case, marked with its TC-ID.

## Wording the code understands (Test Data sheets)

| Column | Allowed |
|---|---|
| Value | a number, `At CRITICAL cut-off`, `Just below CRITICAL cut-off`, `At WATCH cut-off`, `Just below WATCH cut-off`, `n/a` |
| Expected Result | `CRITICAL` / `WATCH` / `HEALTHY`; `Same as full request: <field>, <field>, ...`; `Error names <field>; no risk_level` |
| Action | `Remove`, `Set` |

## Running

First time (Python 3.10 or newer), from inside this folder:

```bash
python -m venv .venv
.venv\Scripts\activate            # Windows PowerShell / cmd   (Git Bash: source .venv/Scripts/activate)
pip install pytest requests openpyxl pyyaml pydantic
```

Then:

```bash
pytest -v -rs                                           # everything; -rs lists every BLOCKED / N/A with its reason

pytest                                                  # everything, default environment
pytest --suite smoke                                    # smoke / sanity / regression
pytest --subsystem cooling                              # one sub-system
pytest --component radiator --suite regression          # narrow further
pytest --env dev                                        # environment from settings.yaml
pytest --vehicle-sample 0                               # TC-07 checks every vehicle (e.g. nightly)
pytest --vehicle-sample 100                             # TC-07 checks up to 100 vehicles
pytest -k TC-07 --vehicle-seed 412907                   # repeat the exact vehicles of an earlier run
```

TC-07 makes one call per vehicle, so on a large fleet it checks a random sample (`vehicle_sample_size`).
Each run checks different vehicles; the seed is printed in the report, and a failure message says how many
vehicles were checked and which seed repeats them.

The summary at the end gives one line per TC-ID: PASS, FAIL, PARTIAL, BLOCKED or NOT APPLICABLE.

## How to extend - step by step

At a glance:

| Change | Excel | Config / data files | Code |
|---|---|---|---|
| New component | Component-specific rows | settings, component profile, request file, assumed sets | None |
| New Send & Verify case | Test Cases row + Test Data rows | - | One short test function |
| New Read & Verify case | Test Cases row | - | One test function with its rule |
| New endpoint in an existing API area | - | Re-pin Swagger if new | One method in that service |
| New API area (new Swagger tag) | - | Re-pin Swagger | One service file + one line |
| New kind of Expected Result | Use the new wording | - | One rule in `result_checker.py` |
| New word in the Value column | Use the new word | - | One rule in `value_resolver.py` |
| New request shape | - | Request file per component, or none | Pydantic model, if fixed shape |
| API changed | - | Re-pin Swagger | Only what the run flags |
| Training/testing APIs arrive | - | `record_sources` | Endpoint in a service |
| Thresholds, exclusions, environments | Excluded Components | Component profile / settings | None |

### A new component (e.g. turbocharger)
1. Check the exact component key in `GET /api/registry` - it goes into every URL and file name.
2. `config/settings.yaml` -> `hierarchy`: add it under its sub-system (create the sub-system if new).
3. `config/components/<name>.yaml`: copy `radiator.yaml`; set cut-offs (from the ML engineer) and the
   mandatory/optional lists (from `GET /api/predict/<name>/features`, confirmed by the ML engineer).
4. `testdata/requests/predict/<name>.json`: one record from `GET /api/<name>/fleet`, keeping only the
   mandatory and optional fields (drop prediction outputs).
5. Sheet **Test Data - Components**: its rows for component-specific cases (today: TC-02).
6. `testdata/assumed/<name>/`: assumed training and testing sets, until the real APIs exist (TC-05).
7. Sheet **Test Cases** -> Excluded Components: only if a case must not run for it.
8. Run `pytest -v -rs --component <name>`. Any BLOCKED line says what is still missing.

No code changes. Rows in the **Test Data** sheet already apply to it.

### A new Send & Verify case (change an input, check the response)
1. Sheet **Test Cases**: new row - TC-ID, Category `Send & Verify`, Suite, API, Method,
   Applicable/Excluded Components, Prerequisites, Expected Result (description), Status `Ready`.
2. Its test data: rows for every component in **Test Data**; rows tied to one component in
   **Test Data - Components**. Expected Result here must use the wording the code understands (see above).
3. `tests/test_send_and_verify.py`: add the test function -
   ```python
   @pytest.mark.case("TC-08")
   def test_tc08_short_name(run, services, builder, settings):
       send_and_verify(run, services, builder, settings)
   ```
4. If its API is not yet in a service, or it needs new wording, see the sections below.
5. Run `pytest -v -k TC-08`.

If step 3 is forgotten, the traceability test fails: "Ready in the Test Cases sheet but no test implements them".

### A new Read & Verify case (fetch existing records, check a rule)
1. Sheet **Test Cases**: new row with Category `Read & Verify`. No test data rows.
2. `tests/test_read_and_verify.py`: a test function marked `@pytest.mark.case("TC-xx")` that fetches through
   `services`, applies its rule to every record, collects all problems, then calls `fail(run, problems)`.
3. If the records come from a source with no API yet: add it to `record_sources` in settings.yaml as
   `type: file` with an assumed file, and read it with `records.records("<name>", component)`.
4. Run `pytest -v -k TC-xx`.

### A new endpoint in an existing API area (same Swagger tag)
1. If the endpoint is new to the API: re-pin Swagger (see "The API changed").
2. Add it to the service for its tag in `framework/services/` - one line in `ENDPOINTS` and one method:
   ```python
   "insights": ("GET", "/api/{component}/insights"),
   def insights(self, component): return self.call("insights", component=component)
   ```
3. Use it from tests as `services.fleet.insights(component)`. The path is now allowed in the Test Cases sheet.

### A new API area (a Swagger tag no service covers yet, e.g. Service Scheduling)
1. Re-pin Swagger if needed.
2. `framework/services/<area>_service.py`: a class like the others - `TAG`, `ENDPOINTS`, one method per endpoint.
3. `framework/services/__init__.py`: one line in `SERVICE_CLASSES` and one attribute in `Services`.
4. If a request body is needed: a fixed-shape body is a pydantic model registered in `FIXED_SHAPE`
   (`request_builder.py`); a body that differs per component is a file `testdata/requests/<area>/<component>.json`.

At start-up the run checks every service path against Swagger, and every Test Cases API path against the services.

### A new kind of Expected Result (Test Data sheets)
1. Decide the exact wording, e.g. `recommended_action is <text>`.
2. `framework/result_checker.py`: add it to `expected_kind()` and the check to `check()`.
3. Add it to "Wording the code understands" in this README.

Until step 2 is done, the run stops at start-up naming the unknown wording - nothing runs half-checked.

### A new word in the Value column (Test Data sheets)
1. `framework/value_resolver.py`: add the phrase and how it becomes a number.
2. Add it to "Wording the code understands" in this README.

### The API changed
1. Download `GET /openapi.json` and save it as `spec/fleet_rul_openapi_v<version>.json`.
2. `config/settings.yaml` -> `swagger`: point to the new file.
3. Run. The run stops if a service path no longer exists. If a request field was renamed,
   TC-06 fails - update the component profile, the request file and any Test Data rows naming it.

### Training/testing data APIs become available
1. Re-pin Swagger.
2. Add the endpoints to the service for their Swagger tag.
3. `config/settings.yaml` -> `record_sources`: set `type: api` and the `endpoint`.
4. TC-05 now reads from the API; the assumed files can be deleted.

### Smaller changes
| Change | Edit |
|---|---|
| Cut-off agreed or changed | `config/components/<name>.yaml` |
| Exclude a component from a case | Sheet **Test Cases** -> Excluded Components |
| Another row for an existing case | **Test Data** (every component) or **Test Data - Components** (one component) |
| Compare one more field in TC-01 | **Test Data** -> TC-01 Expected Result list |
| New environment, e.g. Azure test | `config/settings.yaml` -> `environments`, then `--env <name>` |
| Fewer or more vehicles in TC-07 | `vehicle_sample_size`, or `--vehicle-sample N` |

## Checked locally only

The live API is not reachable from where this was built. `stand_in/app.py` copies the real response
shapes you shared and was used to check every case, including that each one fails on a real defect
(`STANDIN_BUG=...`). Run `pytest --env local_stand_in` to use it.

Shapes assumed, not yet seen from the real API - adjust if they differ:
- `GET /api/registry`: the component name appears in the response
- `GET /api/{component}/vehicle/{unit_id}/history`: a list of records like the fleet records
- Predict with a missing mandatory field: 422 whose body names the field
