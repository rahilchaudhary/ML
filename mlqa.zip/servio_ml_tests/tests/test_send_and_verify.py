"""Send & Verify cases: change an input, send it, check the response.

Each test runs once per component x Test Data row (see conftest.pytest_generate_tests).
"""
import pytest

from framework.flows import fail, send_and_verify


@pytest.mark.case("TC-01")
def test_tc01_optional_field_has_no_impact(run, services, builder, settings, features, baseline):
    if run.row.field not in features(run.component.name)["optional_metadata"]:
        fail(run, [f"test data: '{run.row.field}' is not an optional field per the features API"])
    send_and_verify(run, services, builder, settings, baseline=baseline(run.api, run.component.name))


@pytest.mark.case("TC-02")
def test_tc02_missing_mandatory_field_reports_error(run, services, builder, settings, features):
    if run.row.field not in features(run.component.name)["required_features"]:
        fail(run, [f"test data: '{run.row.field}' is not a mandatory field per the features API"])
    send_and_verify(run, services, builder, settings)


@pytest.mark.case("TC-03")
def test_tc03_rul_within_critical_gives_critical(run, services, builder, settings):
    send_and_verify(run, services, builder, settings)


@pytest.mark.case("TC-04")
def test_tc04_risk_follows_rul_across_boundaries(run, services, builder, settings):
    send_and_verify(run, services, builder, settings)
