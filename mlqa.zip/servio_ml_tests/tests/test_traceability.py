"""Every Ready test case in the Test Cases sheet must have a test that implements it."""
import importlib
from pathlib import Path


def test_every_ready_case_is_implemented(pytestconfig):
    implemented = set()
    for f in Path(__file__).parent.glob("test_*.py"):
        module = importlib.import_module(f"tests.{f.stem}")
        for obj in vars(module).values():
            for mark in getattr(obj, "pytestmark", []):
                if mark.name == "case":
                    implemented.add(mark.args[0])
    ready = {tc for tc, c in pytestconfig._servio.cases.items() if c.ready}
    missing = sorted(ready - implemented)
    assert not missing, f"Ready in the Test Cases sheet but no test implements them: {missing}"
