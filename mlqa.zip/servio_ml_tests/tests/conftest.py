"""Wiring only: run options, selection of what runs, shared fixtures, prerequisites, summary.

Run-time inputs:  --system  --subsystem  --component  --suite  (and --env)
What runs = cases in the chosen suite
            x components in the run's scope AND in the case's (Applicable - Excluded)
"""
from __future__ import annotations

from collections import defaultdict
from types import SimpleNamespace

import pytest

from framework.api_client import ApiClient
from framework.case_reader import SUITES, TestDataError, read_workbook
from framework.component_selector import select
from framework.flows import CaseRun
from framework.record_source import RecordSource
from framework.request_builder import RequestBuilder
from framework.result_checker import expected_kind
from framework.settings import ConfigError, Settings
from framework.swagger import Swagger, UnknownEndpoint
from framework.services import Services, known_endpoints
from framework.vehicle_sample import VehicleSample


# ---------------- run-time inputs ----------------
def pytest_addoption(parser):
    g = parser.getgroup("servio")
    g.addoption("--env", default=None, help="environment from config/settings.yaml")
    g.addoption("--system", default=None, help="e.g. fleet_rul")
    g.addoption("--subsystem", default=None, help="e.g. cooling")
    g.addoption("--component", default=None, help="e.g. radiator")
    g.addoption("--suite", default=None, help="Smoke, Sanity or Regression")
    g.addoption("--vehicle-sample", type=int, default=None,
                help="per-vehicle cases check at most N vehicles (0 = every vehicle)")
    g.addoption("--vehicle-seed", type=int, default=None, help="repeat a previous vehicle sample")


def pytest_configure(config):
    config.addinivalue_line("markers", "case(tc_id): the TC-ID (Test Cases sheet) this test implements")
    try:
        settings = Settings(config.getoption("--env"))
        cases = read_workbook(settings.excel)
        scope = settings.components_in_scope(config.getoption("--system"),
                                             config.getoption("--subsystem"),
                                             config.getoption("--component"))
        suite = config.getoption("--suite")
        if suite and suite.capitalize() not in SUITES:
            raise ConfigError(f"--suite '{suite}' is not one of {SUITES}")
        swagger = Swagger(settings.swagger_file)
        # Every service endpoint must exist in the pinned Swagger.
        endpoints = known_endpoints()
        for (method, path), (key, name) in endpoints.items():
            swagger.check(method, path, where=f"service '{key}.{name}'")
        file_backed = {s["endpoint"] for s in settings.record_sources.values() if s["type"] == "file"}
        api_backed = {s["endpoint"] for s in settings.record_sources.values() if s["type"] == "api"}
        # Fail fast: check every word in the Test Cases and Test Data sheets, and every API path, before any call is made.
        known = list(settings.components)
        for path in api_backed:
            if not any(p == path for (_, p) in endpoints):
                raise ConfigError(f"record source endpoint {path} is type 'api' but no service covers it")
        for case in cases.values():
            select(case, known, known)
            for path in case.apis:
                if path in file_backed:
                    continue
                if (case.method, path) not in endpoints:
                    raise TestDataError(f"{case.tc_id} API: {case.method} {path} is not covered by any service "
                                        f"in framework/services/ (add it to the service for its Swagger tag)")
            for row in case.rows:
                expected_kind(row.expected_result)
                if row.component and row.component not in known:
                    raise TestDataError(f"Test Data - Components {case.tc_id} {row.row}: unknown component "
                                        f"'{row.component}'. Known: {sorted(known)}")
    except (ConfigError, TestDataError, UnknownEndpoint) as e:
        raise pytest.UsageError(str(e)) from None
    config._servio = SimpleNamespace(settings=settings, cases=cases, scope=scope, swagger=swagger,
                                     suite=suite.capitalize() if suite else None)


# ---------------- what runs ----------------
def pytest_generate_tests(metafunc):
    marker = metafunc.definition.get_closest_marker("case")
    if marker is None or "run" not in metafunc.fixturenames:
        return
    ctx = metafunc.config._servio
    tc_id = marker.args[0]
    if tc_id not in ctx.cases:
        raise pytest.UsageError(f"{metafunc.function.__name__} implements {tc_id}, which is not in the Test Cases sheet")
    case = ctx.cases[tc_id]
    params = []
    if not case.ready:
        params.append(pytest.param(None, id=f"{tc_id}|blocked",
                                   marks=pytest.mark.skip(reason=f"BLOCKED: {case.status}")))
    else:
        components = select(case, list(ctx.settings.components), ctx.scope)
        if not components:
            params.append(pytest.param(None, id=f"{tc_id}|not-applicable", marks=pytest.mark.skip(
                reason=f"NOT APPLICABLE: no component left after Applicable/Excluded and run scope")))
        for name in components:
            profile = ctx.settings.components[name]
            if case.category == "Send & Verify":
                rows = case.rows_for(name)
                if not rows:
                    params.append(pytest.param(None, id=f"{tc_id}|{name}|no-data", marks=pytest.mark.skip(
                        reason=f"BLOCKED: no test data for {name}")))
                params += [pytest.param(CaseRun(case, profile, row), id=f"{tc_id}|{name}|{row.row}")
                           for row in rows]
            else:
                params.append(pytest.param(CaseRun(case, profile), id=f"{tc_id}|{name}"))
    metafunc.parametrize("run", params)


def pytest_collection_modifyitems(config, items):
    suite = config._servio.suite
    if not suite:
        return
    keep, drop = [], []
    for item in items:
        m = item.get_closest_marker("case")
        in_suite = m is None or config._servio.cases[m.args[0]].suite == suite
        (keep if in_suite else drop).append(item)
    if drop:
        config.hook.pytest_deselected(items=drop)
        items[:] = keep


# ---------------- shared pieces ----------------
@pytest.fixture(scope="session")
def settings(pytestconfig) -> Settings:
    return pytestconfig._servio.settings


@pytest.fixture(scope="session")
def client(settings, pytestconfig) -> ApiClient:
    return ApiClient(settings.base_url, pytestconfig._servio.swagger)


@pytest.fixture(scope="session")
def services(client) -> Services:
    return Services(client)


@pytest.fixture(scope="session")
def builder() -> RequestBuilder:
    return RequestBuilder()


@pytest.fixture(scope="session")
def vehicle_sample(pytestconfig, settings) -> VehicleSample:
    size = pytestconfig.getoption("--vehicle-sample")
    if size is None:
        size = settings.vehicle_sample_size
    vs = VehicleSample(size or None, pytestconfig.getoption("--vehicle-seed"))
    pytestconfig._servio.vehicle_sample = vs
    return vs


@pytest.fixture(scope="session")
def records(services, settings) -> RecordSource:
    return RecordSource(services, settings.record_sources)


@pytest.fixture(scope="session")
def features(services):
    """Mandatory/optional lists from the features API, fetched once per component."""
    cache = {}

    def get(component: str) -> dict:
        if component not in cache:
            resp = services.prediction.features(component)
            if resp.status != 200:
                pytest.fail(f"Prerequisite failed: features API for {component} returned {resp}", pytrace=False)
            cache[component] = resp.body
        return cache[component]
    return get


@pytest.fixture(scope="session")
def baseline(services, builder):
    """Response to the unchanged full request, sent once per API path and component (TC-01)."""
    cache = {}

    def get(path: str, component: str):
        key = (path, component)
        if key not in cache:
            cache[key] = services.call("POST", path, builder.full_request(path, component), component=component)
            if cache[key].status != 200:
                pytest.fail(f"Prerequisite failed: full request to {path} for {component} returned "
                            f"{cache[key]}", pytrace=False)
        return cache[key]
    return get


# ---------------- common prerequisites ----------------
@pytest.fixture(scope="session")
def _registry_text(services) -> str:
    resp = services.system.health()
    if resp.status != 200:
        pytest.exit(f"Prerequisite failed: API is not up - GET /health returned {resp}", returncode=3)
    reg = services.system.registry()
    if reg.status != 200:
        pytest.exit(f"Prerequisite failed: GET /api/registry returned {reg}", returncode=3)
    return reg.text


@pytest.fixture(autouse=True)
def _component_registered(request):
    run = request.node.callspec.params.get("run") if hasattr(request.node, "callspec") else None
    if run is None:
        return
    if f'"{run.component.name}"' not in request.getfixturevalue("_registry_text"):
        pytest.skip(f"BLOCKED: {run.component.name} is not listed in GET /api/registry")


# ---------------- summary: one line per TC-ID ----------------
_RESULTS: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    rep = outcome.get_result()
    m = item.get_closest_marker("case")
    if not m:
        return
    r = _RESULTS[m.args[0]]
    if rep.when == "call":
        r["passed" if rep.passed else "failed"] += 1
    elif rep.when == "setup" and rep.skipped:
        reason = str(rep.longrepr[-1]) if isinstance(rep.longrepr, tuple) else ""
        r["not applicable" if "NOT APPLICABLE" in reason else "blocked"] += 1
    elif rep.when == "setup" and rep.failed:
        r["failed"] += 1


def pytest_terminal_summary(terminalreporter, config):
    if not _RESULTS:
        return
    tr = terminalreporter
    vs = getattr(config._servio, "vehicle_sample", None)
    if vs is not None:
        tr.section("Vehicle sample")
        tr.write_line("every vehicle" if vs.size is None else
                      f"up to {vs.size} vehicles per component, seed {vs.seed} "
                      f"(repeat with --vehicle-seed {vs.seed})")
    tr.section("Result by test case")
    tr.write_line(f"{'TC-ID':<8}{'Result':<16}{'Passed':>7}{'Failed':>7}{'Blocked':>8}{'N/A':>5}")
    for tc in sorted(_RESULTS):
        r = _RESULTS[tc]
        verdict = ("FAIL" if r["failed"] else "PASS" if r["passed"] and not r["blocked"]
                   else "PARTIAL" if r["passed"] else "BLOCKED" if r["blocked"] else "NOT APPLICABLE")
        tr.write_line(f"{tc:<8}{verdict:<16}{r['passed']:>7}{r['failed']:>7}{r['blocked']:>8}{r['not applicable']:>5}")
