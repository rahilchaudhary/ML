"""Read & Verify cases: fetch existing records, apply a rule to every one, report all failures together.

Each test runs once per component (see conftest.pytest_generate_tests).
Calls go through the service objects (framework/services/); no paths are written here.
"""
import pytest

from framework.flows import fail
from framework.record_source import extract_records

RUL_FIELDS = ("predicted_rul_hours", "rul_lower_hours", "rul_upper_hours")


@pytest.mark.case("TC-05")
def test_tc05_training_and_testing_have_no_duplicate_fleets(run, records):
    training = records.records("training_set", run.component.name)
    testing = records.records("testing_set", run.component.name)
    problems = []
    for key in ("unit_id", "vin"):
        both = sorted({r.get(key) for r in training} & {r.get(key) for r in testing} - {None, ""})
        if both:
            problems.append(f"{key} in both training and testing: {both}")
    fail(run, problems)


@pytest.mark.case("TC-06")
def test_tc06_mandatory_and_optional_fields_marked_correctly(run, services):
    comp = run.component
    feat = services.prediction.features(comp.name)
    if feat.status != 200:
        fail(run, [f"features call returned {feat}"])
    api = feat.body
    problems = []
    for api_key, agreed in (("required_features", comp.mandatory_fields),
                            ("optional_metadata", comp.optional_fields)):
        listed = set(api.get(api_key, []))
        if listed != set(agreed):
            problems.append(f"{api_key}: missing {sorted(set(agreed) - listed)}, "
                            f"unexpected {sorted(listed - set(agreed))}")
    resp = services.fleet.fleet(comp.name)
    if resp.status != 200:
        fail(run, problems + [f"fleet call returned {resp}"])
    for rec in extract_records(resp.body):
        empty = [f for f in comp.mandatory_fields if rec.get(f) in (None, "")]
        if empty:
            problems.append(f"fleet record {rec.get('unit_id')}: no value in {empty}")
    fail(run, problems)


@pytest.mark.case("TC-07")
def test_tc07_history_records_have_positive_rul(run, services, vehicle_sample):
    comp = run.component.name
    fleet = services.fleet.fleet(comp)
    if fleet.status != 200:
        fail(run, [f"fleet call returned {fleet}"])
    all_ids = sorted({r["unit_id"] for r in extract_records(fleet.body) if r.get("unit_id")})
    if not all_ids:
        fail(run, ["prerequisite: fleet has no vehicles"])
    unit_ids = vehicle_sample.pick(all_ids)        # large fleets: a reproducible random sample
    problems = []
    for uid in unit_ids:
        resp = services.fleet.history(comp, uid)
        if resp.status != 200:
            problems.append(f"{uid}: history call returned {resp}")
            continue
        for i, rec in enumerate(extract_records(resp.body)):
            bad = {f: rec.get(f) for f in RUL_FIELDS
                   if not isinstance(rec.get(f), (int, float)) or rec.get(f) < 0}
            if bad:
                problems.append(f"{uid} record {i}: {bad}")
    if problems:
        problems.append(f"checked {vehicle_sample.describe(len(unit_ids), len(all_ids))}")
    fail(run, problems)
