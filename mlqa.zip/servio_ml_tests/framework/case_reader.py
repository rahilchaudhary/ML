"""Case reader: reads the test case workbook and hands out each test case with its test data rows.

Sheets:
  Test Cases               - one row per test case
  Test Data                - rows that apply to every component the case runs for
  Test Data - Components   - rows tied to one component (Component column)

Checks the fixed vocabulary when loading, so a mistyped word stops the run
with a clear message instead of producing a confusing failure later.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import openpyxl

CATEGORIES = ("Send & Verify", "Read & Verify")
SUITES = ("Smoke", "Sanity", "Regression")
ACTIONS = ("Remove", "Set")
METHODS = ("GET", "POST", "PUT", "DELETE")

CASE_HEADERS = ("TC-ID", "Test Case", "Category", "Suite", "API", "Method",
                "Applicable Components", "Excluded Components", "Prerequisites",
                "Expected Result", "Status")
DATA_HEADERS = ("TC-ID", "Row", "Field", "Action", "Value", "Expected Status", "Expected Result")
COMPONENT_DATA_HEADERS = DATA_HEADERS + ("Component",)

CASES_SHEET, DATA_SHEET, COMPONENT_DATA_SHEET = "Test Cases", "Test Data", "Test Data - Components"


class TestDataError(ValueError):
    """A sheet of the test case workbook contains something the code cannot understand."""


@dataclass(frozen=True)
class DataRow:
    tc_id: str
    row: str
    field: str
    action: str
    value: str
    expected_status: int
    expected_result: str
    component: str | None = None     # None = applies to every component (Test Data sheet)


@dataclass
class TestCase:
    tc_id: str
    title: str
    category: str
    suite: str
    apis: list[str]          # API column, one path per line, in the order the test calls them
    method: str
    applicable: str
    excluded: str
    status: str
    rows: list[DataRow] = field(default_factory=list)

    @property
    def ready(self) -> bool:
        return self.status == "Ready"

    def rows_for(self, component: str) -> list[DataRow]:
        """Rows for every component, plus rows tied to this one."""
        return [r for r in self.rows if r.component in (None, component)]


def _sheet(ws, headers: tuple[str, ...]) -> list[dict[str, str]]:
    rows = list(ws.iter_rows(values_only=True))
    at = next((i for i, r in enumerate(rows) if r and r[0] == "TC-ID"), None)
    if at is None:
        raise TestDataError(f"Sheet '{ws.title}': no header row starting with 'TC-ID'")
    found = [str(h).strip() if h else "" for h in rows[at]]
    missing = [h for h in headers if h not in found]
    if missing:
        raise TestDataError(f"Sheet '{ws.title}': missing columns {missing}")
    return [{h: ("" if v is None else str(v).strip()) for h, v in zip(found, r) if h}
            for r in rows[at + 1:] if r and r[0]]


def _one_of(value: str, allowed: tuple[str, ...], where: str) -> str:
    if value not in allowed:
        raise TestDataError(f"{where}: '{value}' is not one of {allowed}")
    return value


def read_workbook(path: Path) -> dict[str, TestCase]:
    wb = openpyxl.load_workbook(path, data_only=True)
    cases: dict[str, TestCase] = {}
    for r in _sheet(wb[CASES_SHEET], CASE_HEADERS):
        tc = r["TC-ID"]
        if tc in cases:
            raise TestDataError(f"Test Cases: duplicate {tc}")
        cases[tc] = TestCase(
            tc_id=tc, title=r["Test Case"],
            category=_one_of(r["Category"], CATEGORIES, f"{tc} Category"),
            suite=_one_of(r["Suite"], SUITES, f"{tc} Suite"),
            apis=[line.strip() for line in r["API"].splitlines() if line.strip()],
            method=_one_of(r["Method"].upper(), METHODS, f"{tc} Method"),
            applicable=r["Applicable Components"] or "All",
            excluded=r["Excluded Components"] or "None",
            status=r["Status"])
    _add_rows(cases, _sheet(wb[DATA_SHEET], DATA_HEADERS), DATA_SHEET)
    if COMPONENT_DATA_SHEET in wb.sheetnames:
        _add_rows(cases, _sheet(wb[COMPONENT_DATA_SHEET], COMPONENT_DATA_HEADERS), COMPONENT_DATA_SHEET)
    return cases


def _add_rows(cases: dict[str, TestCase], rows: list[dict[str, str]], sheet: str) -> None:
    for r in rows:
        tc, component = r["TC-ID"], r.get("Component") or None
        where = f"{sheet} {tc} {component + ' ' if component else ''}{r['Row']}"
        if tc not in cases:
            raise TestDataError(f"{where}: no such test case")
        if cases[tc].category != "Send & Verify":
            raise TestDataError(f"{where}: {tc} is Read & Verify and takes no test data")
        if sheet == COMPONENT_DATA_SHEET and not component:
            raise TestDataError(f"{where}: Component is empty")
        try:
            status = int(float(r["Expected Status"]))
        except ValueError:
            raise TestDataError(f"{where}: Expected Status '{r['Expected Status']}' is not a number") from None
        cases[tc].rows.append(DataRow(
            tc_id=tc, row=r["Row"], field=r["Field"],
            action=_one_of(r["Action"], ACTIONS, f"{where} Action"),
            value=r["Value"], expected_status=status, expected_result=r["Expected Result"],
            component=component))
