"""Swagger tag: RUL Recommendation."""
from framework.api_client import ApiResponse
from framework.services.base import BaseService


class RecommendationService(BaseService):
    TAG = "RUL Recommendation"
    ENDPOINTS = {
        "recommend": ("POST", "/api/recommendation/{component}"),
    }

    def recommend(self, component: str, body: dict) -> ApiResponse:
        return self.call("recommend", body=body, component=component)
