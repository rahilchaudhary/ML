"""All service objects in one place.

A new API area = a new service file + one line in SERVICE_CLASSES. Tests never write paths.
"""
from __future__ import annotations

from framework.api_client import ApiClient, ApiResponse
from framework.services.base import BaseService
from framework.services.fleet_service import FleetService
from framework.services.prediction_service import PredictionService
from framework.services.recommendation_service import RecommendationService
from framework.services.system_service import SystemService

SERVICE_CLASSES: dict[str, type[BaseService]] = {
    "prediction": PredictionService,
    "recommendation": RecommendationService,
    "fleet": FleetService,
    "system": SystemService,
}


def known_endpoints() -> dict[tuple[str, str], tuple[str, str]]:
    """(method, path) -> (service key, endpoint name), for every endpoint any service covers."""
    return {(m, p): (key, name)
            for key, cls in SERVICE_CLASSES.items()
            for name, (m, p) in cls.ENDPOINTS.items()}


class Services:
    def __init__(self, client: ApiClient):
        self.prediction = PredictionService(client)
        self.recommendation = RecommendationService(client)
        self.fleet = FleetService(client)
        self.system = SystemService(client)

    def call(self, method: str, path: str, body: dict | None = None, **path_values) -> ApiResponse:
        """Used by the generic Send & Verify flow, where the path comes from the Test Cases sheet."""
        key, name = known_endpoints()[(method.upper(), path)]
        return getattr(self, key).call(name, body=body, **path_values)
