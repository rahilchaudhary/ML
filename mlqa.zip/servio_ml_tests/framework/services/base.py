"""Base for service objects: one class per Swagger tag, the only place an API path is written.

A service lists its endpoints in ENDPOINTS:  name -> (method, path as Swagger writes it).
Its methods call self.call(name, ...). HTTP itself stays in ApiClient.
"""
from __future__ import annotations

from framework.api_client import ApiClient, ApiResponse


class BaseService:
    TAG: str = ""                                   # the Swagger tag this service covers
    ENDPOINTS: dict[str, tuple[str, str]] = {}      # name -> (method, path)

    def __init__(self, client: ApiClient):
        self.client = client

    def call(self, name: str, body: dict | None = None, params: dict | None = None,
             **path_values) -> ApiResponse:
        method, path = self.ENDPOINTS[name]
        return self.client.request(method, path, body=body, params=params, **path_values)
