"""Swagger tag: Predictions (per-component fleet and vehicle records)."""
from framework.api_client import ApiResponse
from framework.services.base import BaseService


class FleetService(BaseService):
    TAG = "Predictions"
    ENDPOINTS = {
        "fleet":   ("GET", "/api/{component}/fleet"),
        "history": ("GET", "/api/{component}/vehicle/{unit_id}/history"),
    }

    def fleet(self, component: str) -> ApiResponse:
        return self.call("fleet", component=component)

    def history(self, component: str, unit_id: str) -> ApiResponse:
        return self.call("history", component=component, unit_id=unit_id)
