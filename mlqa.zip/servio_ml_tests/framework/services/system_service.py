"""Swagger tags: System and Registry (is the API up, which components exist)."""
from framework.api_client import ApiResponse
from framework.services.base import BaseService


class SystemService(BaseService):
    TAG = "System / Registry"
    ENDPOINTS = {
        "health":   ("GET", "/health"),
        "registry": ("GET", "/api/registry"),
    }

    def health(self) -> ApiResponse:
        return self.call("health")

    def registry(self) -> ApiResponse:
        return self.call("registry")
