"""Swagger tag: On-Demand Prediction."""
from framework.api_client import ApiResponse
from framework.services.base import BaseService


class PredictionService(BaseService):
    TAG = "On-Demand Prediction"
    ENDPOINTS = {
        "predict":  ("POST", "/api/predict/{component}"),
        "features": ("GET",  "/api/predict/{component}/features"),
    }

    def predict(self, component: str, body: dict) -> ApiResponse:
        return self.call("predict", body=body, component=component)

    def features(self, component: str) -> ApiResponse:
        return self.call("features", component=component)
