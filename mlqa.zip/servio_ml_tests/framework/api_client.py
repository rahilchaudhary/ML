"""API client: the only place that makes HTTP calls.

Callers pass the path as Swagger writes it (e.g. /api/predict/{component}).
Every call is checked against the pinned Swagger first, so a path that is not
in the API fails with a clear message instead of a confusing 404.
"""
from __future__ import annotations

import json

import requests

from framework.swagger import Swagger


class ApiResponse:
    def __init__(self, raw: requests.Response):
        self.status = raw.status_code
        self.text = raw.text
        try:
            self.body = raw.json()
        except ValueError:
            self.body = None

    def __repr__(self):
        return f"HTTP {self.status} {self.text[:300]}"


class ApiClient:
    def __init__(self, base_url: str, swagger: Swagger, timeout: float = 30.0):
        self.base_url = base_url
        self.swagger = swagger
        self.timeout = timeout
        self.http = requests.Session()

    def request(self, method: str, path: str, body: dict | None = None,
                params: dict | None = None, **path_values) -> ApiResponse:
        self.swagger.check(method, path)
        url = self.base_url + path.format(**path_values)
        data = json.dumps(body) if body is not None else None
        headers = {"Content-Type": "application/json"} if body is not None else None
        raw = self.http.request(method.upper(), url, data=data, params=params,
                                headers=headers, timeout=self.timeout)
        return ApiResponse(raw)

    def get(self, path: str, params: dict | None = None, **path_values) -> ApiResponse:
        return self.request("GET", path, params=params, **path_values)

    def post(self, path: str, body: dict, **path_values) -> ApiResponse:
        return self.request("POST", path, body=body, **path_values)
