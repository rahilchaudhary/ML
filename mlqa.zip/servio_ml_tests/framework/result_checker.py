"""Result checker: compares a response with Expected Status and Expected Result.

Allowed Expected Result wording (anything else is a test data error):
    CRITICAL / WATCH / HEALTHY                     risk_level must equal it
    Same as full request: <field>, <field>, ...    these fields equal the full-request response
    Error names <field>; no risk_level             <field> appears in the error, and no risk_level is returned
"""
from __future__ import annotations

import re

from framework.api_client import ApiResponse
from framework.case_reader import DataRow, TestDataError
from framework.settings import CRITICAL, HEALTHY, WATCH

_ERROR_NAMES = re.compile(r"^Error names\s+(\S+?)\s*;\s*no risk_level$", re.IGNORECASE)
_SAME_AS_FULL = re.compile(r"^Same as full request\s*:\s*(.+)$", re.IGNORECASE)


def expected_kind(text: str) -> str:
    """Classify the wording once, so a typo is caught before any call is made."""
    t = (text or "").strip()
    if t in (CRITICAL, WATCH, HEALTHY):
        return "risk"
    if _SAME_AS_FULL.match(t):
        return "same_as_full"
    if _ERROR_NAMES.match(t):
        return "error_names"
    raise TestDataError(f"Expected Result '{t}' is not understood. Use CRITICAL/WATCH/HEALTHY, "
                        f"'Same as full request: <field>, <field>' or 'Error names <field>; no risk_level'")


def compared_fields(text: str) -> list[str]:
    """Fields listed after 'Same as full request:'."""
    return [f.strip() for f in _SAME_AS_FULL.match(text.strip()).group(1).split(",") if f.strip()]


def check(resp: ApiResponse, row: DataRow, baseline: ApiResponse | None = None) -> list[str]:
    """Return every mismatch (empty list = pass)."""
    problems = []
    if resp.status != row.expected_status:
        problems.append(f"status {resp.status}, expected {row.expected_status} - {resp.text[:200]}")
    body = resp.body if isinstance(resp.body, dict) else {}
    kind = expected_kind(row.expected_result)
    if kind == "risk":
        actual = body.get("risk_level")
        if actual != row.expected_result:
            problems.append(f"risk_level {actual}, expected {row.expected_result}")
    elif kind == "error_names":
        field = _ERROR_NAMES.match(row.expected_result.strip()).group(1)
        if field not in resp.text:
            problems.append(f"error does not name '{field}': {resp.text[:200]}")
        if "risk_level" in body:
            problems.append(f"risk_level returned ({body['risk_level']}) although the request was rejected")
    elif kind == "same_as_full":
        base = baseline.body if baseline and isinstance(baseline.body, dict) else {}
        for f in compared_fields(row.expected_result):
            if f not in base:
                problems.append(f"'{f}' is not in the full-request response - check the field name in Expected Result (Test Data sheet)")
            elif body.get(f) != base.get(f):
                problems.append(f"{f} = {body.get(f)}, full request gave {base.get(f)}")
    return problems
