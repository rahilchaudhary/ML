"""Settings: run settings, component requirements and the component hierarchy.

Only loads and exposes facts from config/. No HTTP, no test case workbook, no test logic.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent

CRITICAL, WATCH, HEALTHY = "CRITICAL", "WATCH", "HEALTHY"


class ConfigError(ValueError):
    """Something in config/ is missing or inconsistent."""


@dataclass(frozen=True)
class ComponentProfile:
    """One component's requirements (config/components/<name>.yaml)."""
    name: str
    critical_cut_off: float
    watch_cut_off: float
    mandatory_fields: tuple[str, ...]
    optional_fields: tuple[str, ...]

    def expected_risk(self, rul_lower_hours: float) -> str:
        if rul_lower_hours < self.critical_cut_off:
            return CRITICAL
        if rul_lower_hours < self.watch_cut_off:
            return WATCH
        return HEALTHY

    @classmethod
    def load(cls, name: str) -> "ComponentProfile":
        path = ROOT / "config" / "components" / f"{name}.yaml"
        if not path.exists():
            raise ConfigError(f"Component '{name}' is in the hierarchy but {path} is missing")
        raw = yaml.safe_load(path.read_text())
        try:
            return cls(name=name,
                       critical_cut_off=float(raw["cut_offs"]["critical"]),
                       watch_cut_off=float(raw["cut_offs"]["watch"]),
                       mandatory_fields=tuple(raw["mandatory_fields"]),
                       optional_fields=tuple(raw["optional_fields"]))
        except KeyError as e:
            raise ConfigError(f"{path.name}: missing {e}") from None


class Settings:
    def __init__(self, env: str | None = None):
        raw = yaml.safe_load((ROOT / "config" / "settings.yaml").read_text())
        self.env = env or raw["environment"]
        if self.env not in raw["environments"]:
            raise ConfigError(f"Unknown environment '{self.env}'. Known: {list(raw['environments'])}")
        self.base_url: str = raw["environments"][self.env]["base_url"].rstrip("/")
        self.excel: Path = ROOT / raw["excel"]
        self.swagger_file: Path = ROOT / raw["swagger"]
        if not self.swagger_file.exists():
            raise ConfigError(f"Pinned Swagger file not found: {self.swagger_file}")
        self.record_sources: dict[str, dict] = raw["record_sources"]
        self.just_below_step: float = float(raw["just_below_step"])
        size = raw.get("vehicle_sample_size")
        self.vehicle_sample_size: int | None = int(size) if size else None
        self.hierarchy: dict[str, dict[str, list[str]]] = raw["hierarchy"]
        self.components: dict[str, ComponentProfile] = {
            name: ComponentProfile.load(name)
            for subsystems in self.hierarchy.values()
            for names in subsystems.values()
            for name in names}

    def components_in_scope(self, system: str | None = None, subsystem: str | None = None,
                            component: str | None = None) -> list[str]:
        """Narrow the hierarchy by whatever the user passed at run time."""
        systems = self.hierarchy
        if system:
            if system not in systems:
                raise ConfigError(f"Unknown system '{system}'. Known: {list(systems)}")
            systems = {system: systems[system]}
        found = []
        for subs in systems.values():
            for sub_name, names in subs.items():
                if subsystem and sub_name != subsystem:
                    continue
                found += names
        if subsystem and not found:
            raise ConfigError(f"Unknown sub-system '{subsystem}' in the chosen system")
        if component:
            if component not in found:
                raise ConfigError(f"Component '{component}' is not in the chosen system/sub-system")
            found = [component]
        return found
