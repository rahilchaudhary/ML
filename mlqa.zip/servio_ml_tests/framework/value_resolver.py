"""Value resolver: turns the words in the Value column of the Test Data sheet into a number for one component.

Allowed words (anything else is a test data error):
    a number                       e.g. 0, 150.5
    At CRITICAL cut-off            the component's CRITICAL cut-off
    Just below CRITICAL cut-off    that cut-off minus the step in settings.yaml
    At WATCH cut-off
    Just below WATCH cut-off
    n/a                            no value (Remove rows)
"""
from __future__ import annotations

import re

from framework.case_reader import TestDataError
from framework.settings import ComponentProfile

_PHRASE = re.compile(r"^(at|just below)\s+(critical|watch)\s+cut-off$", re.IGNORECASE)


def resolve(text: str, profile: ComponentProfile, step: float) -> float | None:
    t = (text or "").strip()
    if t.lower() in ("", "n/a"):
        return None
    try:
        return float(t)
    except ValueError:
        pass
    m = _PHRASE.match(t)
    if not m:
        raise TestDataError(f"Value '{t}' is not understood. Use a number, 'At CRITICAL cut-off', "
                            f"'Just below CRITICAL cut-off', 'At WATCH cut-off' or 'Just below WATCH cut-off'")
    cut_off = profile.critical_cut_off if m.group(2).lower() == "critical" else profile.watch_cut_off
    return round(cut_off - step, 6) if m.group(1).lower() == "just below" else cut_off
