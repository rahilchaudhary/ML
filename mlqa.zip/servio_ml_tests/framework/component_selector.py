"""Component selector: which components a test case runs for.

    runs for = (Applicable - Excluded)  AND  in the run's scope
Applicable: "All" or a comma list.  Excluded: "None", "All" or a comma list.
Exclusion always wins. An empty result means the case is NOT APPLICABLE.
"""
from __future__ import annotations

from framework.case_reader import TestCase, TestDataError


def _names(cell: str, known: list[str], where: str) -> set[str]:
    text = (cell or "").strip()
    if text.lower() == "all":
        return set(known)
    if text.lower() in ("none", "-", ""):
        return set()
    names = {n.strip() for n in text.split(",") if n.strip()}
    unknown = sorted(names - set(known))
    if unknown:
        raise TestDataError(f"{where}: unknown component(s) {unknown}. Known: {sorted(known)}")
    return names


def select(case: TestCase, known: list[str], in_scope: list[str]) -> list[str]:
    applicable = _names(case.applicable, known, f"{case.tc_id} Applicable Components")
    excluded = _names(case.excluded, known, f"{case.tc_id} Excluded Components")
    return [c for c in in_scope if c in applicable and c not in excluded]
