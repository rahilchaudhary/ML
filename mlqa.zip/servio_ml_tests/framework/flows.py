"""The two flows every test follows - written once, used by every test.

Send & Verify : resolve value -> build request -> send -> check   (one data row)
Read & Verify : the test fetches records and applies its rule; fail() reports all problems at once
"""
from __future__ import annotations

from dataclasses import dataclass

import pytest

from framework.api_client import ApiResponse
from framework.case_reader import DataRow, TestCase
from framework.request_builder import RequestBuilder
from framework.result_checker import check
from framework.services import Services
from framework.settings import ComponentProfile, Settings
from framework.value_resolver import resolve


@dataclass(frozen=True)
class CaseRun:
    """One concrete run: a test case, for one component, with one data row (Send & Verify only)."""
    case: TestCase
    component: ComponentProfile
    row: DataRow | None = None

    @property
    def api(self) -> str:
        """The case's API path from the Test Cases sheet (Send & Verify cases call one API)."""
        return self.case.apis[0]

    def __str__(self):
        return f"{self.case.tc_id} | {self.component.name}" + (f" | {self.row.row}" if self.row else "")


def send_and_verify(run: CaseRun, services: Services, builder: RequestBuilder, settings: Settings,
                    baseline: ApiResponse | None = None) -> ApiResponse:
    row, comp = run.row, run.component
    value = resolve(row.value, comp, settings.just_below_step) if row.action == "Set" else None
    body = builder.build(run.api, comp.name, row, value)
    resp = services.call(run.case.method, run.api, body=body, component=comp.name)
    fail(run, check(resp, row, baseline))
    return resp


def fail(run: CaseRun, problems: list[str]) -> None:
    if problems:
        pytest.fail(f"{run}:\n  - " + "\n  - ".join(problems), pytrace=False)
